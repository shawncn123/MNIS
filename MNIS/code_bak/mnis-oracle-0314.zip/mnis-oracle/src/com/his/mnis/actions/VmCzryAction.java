package com.his.mnis.actions;

import java.io.ByteArrayInputStream;
import java.io.InputStream;
import java.io.UnsupportedEncodingException;
import java.util.List;
import java.util.Map;

import org.apache.struts2.interceptor.RequestAware;
import org.apache.struts2.interceptor.SessionAware;
import org.apache.struts2.views.freemarker.tags.SetModel;
import org.hibernate.Session;

import com.his.mnis.dao.BaseDao;
import com.his.mnis.entities.VmBmry;
import com.his.mnis.entities.VmCzry;
import com.his.mnis.service.VmBmryService;
import com.his.mnis.service.VmCzryService;
import com.opensymphony.xwork2.ActionSupport;
import com.opensymphony.xwork2.ModelDriven;
import com.opensymphony.xwork2.Preparable;

public class VmCzryAction extends ActionSupport implements RequestAware,
		SessionAware, ModelDriven<VmCzry>, Preparable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private VmCzryService vmCzryService;
	
	private VmBmryService vmBmryService;

	public void setVmCzryService(VmCzryService vmCzryService) {
		this.vmCzryService = vmCzryService;
	}
	
	public void setVmBmryService(VmBmryService vmBmryService) {
		this.vmBmryService = vmBmryService;
	}

	public void setModel(VmCzry model) {
		this.model = model;
	}

	private String yonghu_name;

	private String mima;


	public void setYonghu_name(String yonghu_name) {
		this.yonghu_name = yonghu_name;
	}

	public void setMima(String mima) {
		this.mima = mima;
	}

	public String login() throws UnsupportedEncodingException {
		
		VmCzry vmCzry = vmCzryService.checkCzry(yonghu_name, mima);
		 
		System.out.println(vmCzry.getCzy_id().toString());
		
		if (vmCzry == null) {
			request.put("logincheck", "0");
			return "false";
		} else {
			session.put("czry", vmCzry);
			request.put("logincheck", "1");
			request.put("czybumeng", vmBmryService.getBmById(vmCzry.getCzy_id()));
			System.out.println(model);
			return SUCCESS;
		}
	}

	public String test() {
		System.out.println(yonghu_name);
		vmCzryService.checkCzry(yonghu_name, mima);
		return SUCCESS;
	}

	@Override
	public void prepare() throws Exception {

	}

	private VmCzry model;
	


	@Override
	public VmCzry getModel() {
		if(model == null){
			model = new VmCzry();
		}
		return model;
	}

	private Map<String, Object> request;
	private Map<String, Object> session;

	@Override
	public void setRequest(Map<String, Object> arg0) {
		this.request = arg0;
	}

	@Override
	public void setSession(Map<String, Object> arg0) {
		this.session = arg0;
	}

}
